const express = require('express')
const mongoose = require('mongoose');


const app = express()
const port = 3002
app.use(express.urlencoded({extended:true}))
const mydata=require("./models/mydataschema")


app.get('/', (req, res) => {
  res.sendFile("./views/home.html",{root:__dirname})
})
mongoose
.connect
('mongodb+srv://<db_username>:GHUJVCXS@cluster0.0mmtg1x.mongodb.net/all-data?appName=Cluster0');
.then(()=>{
    app.listen(port, () => (
       console.log(`http://localhost:${port}`)))

})
.catch((err)=>{
    console.log(err)
})
app.post('/', (req, res) => {
console.log(req.body)
const mydata=new mydata(req.body)
mydata.save().
.then(()=>{res.redirect("/")

})
.catch((err)=>{
    console.log(err)
})
})


